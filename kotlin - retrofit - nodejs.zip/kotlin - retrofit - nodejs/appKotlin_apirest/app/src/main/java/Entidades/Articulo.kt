package Entidades

class Articulo {
    var nombre:String = ""
    var id:String = ""
    var descripcion:String = ""
    var cantidad:Int = 0
}